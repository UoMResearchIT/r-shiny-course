# RSE 18 Conference Workshop - Shiny

The workshop website is at: https://uomresearchit.github.io/RSE18-shiny-workshop/



